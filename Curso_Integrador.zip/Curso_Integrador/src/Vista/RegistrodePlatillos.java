package Vista;
import javax.swing.*;
import Modelo.Plato;
import java.math.BigDecimal;
import javax.swing.JButton;
import Controlador.ControladorTablaDePlatos;

public class RegistrodePlatillos extends javax.swing.JPanel {

    private ControladorTablaDePlatos controlador;
    
    public RegistrodePlatillos(ControladorTablaDePlatos controlador) {
        initComponents();
        this.controlador = controlador;
    }


    public JButton getjButtonGuardarPlatillo() {
        return jButtonGuardarPlatillo;
    }
    public JButton getjButtonLimpiarFormulario() {
        return jButtonLimpiarFormulario;
    }

    public Plato getPlato() {
    try {
        int id = TextID.getText().isEmpty() ? 0 : Integer.parseInt(TextID.getText());
        String nombre = textNombrePlatillo.getText().trim();
        String descripcion = textDescripcionPlatillo.getText().trim();
        BigDecimal precio = new BigDecimal(textPrecioPlatillo.getText().trim());

        if (nombre.isEmpty() || descripcion.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Nombre y descripción no pueden estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }

        return new Plato(id, nombre, precio, descripcion);

    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "El precio debe ser un número válido.", "Error", JOptionPane.ERROR_MESSAGE);
    } catch (IllegalArgumentException e) {
        JOptionPane.showMessageDialog(this, e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    return null;
    }

    public void setPlato(Plato plato) {
        if (plato != null) {
            TextID.setText(String.valueOf(plato.getId_plato()));
            textNombrePlatillo.setText(plato.getNombre());
            textPrecioPlatillo.setText(plato.getPrecio().toPlainString());
            textDescripcionPlatillo.setText(plato.getDescripcion());
        }
    }

    public JButton getjButtonCancelar() {
    return jButtonCancelar;
    }
    
    public void limpiarFormulario() {
    TextID.setText("");
    textNombrePlatillo.setText("");
    textPrecioPlatillo.setText("");
    textDescripcionPlatillo.setText("");
    }

    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jLabelID = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButtonGuardarPlatillo = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        textNombrePlatillo = new javax.swing.JTextField();
        textPrecioPlatillo = new javax.swing.JTextField();
        textDescripcionPlatillo = new javax.swing.JTextField();
        jButtonLimpiarFormulario = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabelNombre = new javax.swing.JLabel();
        TextID = new javax.swing.JLabel();
        jButtonCancelar = new javax.swing.JButton();

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("jRadioButtonMenuItem1");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        jLabelID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelID.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelID.setText("ID:");
        jLabelID.setAlignmentX(50.0F);
        jLabelID.setAlignmentY(50.0F);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("Precio:");
        jLabel4.setAlignmentX(50.0F);
        jLabel4.setAlignmentY(50.0F);

        jButtonGuardarPlatillo.setBackground(new java.awt.Color(51, 51, 51));
        jButtonGuardarPlatillo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonGuardarPlatillo.setForeground(new java.awt.Color(255, 255, 255));
        jButtonGuardarPlatillo.setText("Guardar");
        jButtonGuardarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGuardarPlatilloActionPerformed(evt);
            }
        });

        jLabel7.setText("Descripcion:");

        jButtonLimpiarFormulario.setBackground(new java.awt.Color(51, 51, 51));
        jButtonLimpiarFormulario.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonLimpiarFormulario.setForeground(new java.awt.Color(255, 255, 255));
        jButtonLimpiarFormulario.setText("Limpiar");
        jButtonLimpiarFormulario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLimpiarFormularioActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(102, 102, 102));

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Registrar Plato");
        jLabel2.setAlignmentX(140.0F);
        jLabel2.setAlignmentY(10.0F);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(47, 47, 47))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel2)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jLabelNombre.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabelNombre.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelNombre.setText("Nombre:");
        jLabelNombre.setAlignmentX(50.0F);
        jLabelNombre.setAlignmentY(50.0F);

        TextID.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        TextID.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        TextID.setAlignmentX(50.0F);
        TextID.setAlignmentY(50.0F);

        jButtonCancelar.setBackground(new java.awt.Color(51, 51, 51));
        jButtonCancelar.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonCancelar.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel7)
                            .addComponent(jLabelID)
                            .addComponent(jLabelNombre))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(textPrecioPlatillo, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textNombrePlatillo, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(TextID, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(textDescripcionPlatillo, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addComponent(jButtonGuardarPlatillo)
                        .addGap(33, 33, 33)
                        .addComponent(jButtonLimpiarFormulario)
                        .addGap(31, 31, 31)
                        .addComponent(jButtonCancelar)))
                .addContainerGap(90, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabelID)
                    .addComponent(TextID, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelNombre)
                    .addComponent(textNombrePlatillo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(textPrecioPlatillo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(textDescripcionPlatillo, javax.swing.GroupLayout.DEFAULT_SIZE, 65, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonLimpiarFormulario)
                    .addComponent(jButtonGuardarPlatillo)
                    .addComponent(jButtonCancelar))
                .addGap(17, 17, 17))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonLimpiarFormularioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLimpiarFormularioActionPerformed
        limpiarFormulario();
    }//GEN-LAST:event_jButtonLimpiarFormularioActionPerformed

    private void jButtonGuardarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGuardarPlatilloActionPerformed
        controlador.guardarPlato();
    }//GEN-LAST:event_jButtonGuardarPlatilloActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        controlador.volverATabla();
    }//GEN-LAST:event_jButtonCancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel TextID;
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonGuardarPlatillo;
    private javax.swing.JButton jButtonLimpiarFormulario;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabelID;
    private javax.swing.JLabel jLabelNombre;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JTextField textDescripcionPlatillo;
    private javax.swing.JTextField textNombrePlatillo;
    private javax.swing.JTextField textPrecioPlatillo;
    // End of variables declaration//GEN-END:variables

}
