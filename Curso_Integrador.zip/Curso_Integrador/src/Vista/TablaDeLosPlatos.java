package Vista;

import Controlador.ControladorTablaDePlatos;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class TablaDeLosPlatos extends javax.swing.JPanel {

    private ControladorTablaDePlatos controlador;
    
    public TablaDeLosPlatos(ControladorTablaDePlatos controlador) {
        initComponents();
       this.controlador = controlador;
    }

    public JButton getjButtonAgregarPlatillos() {
        return jButtonAgregarPlatillos;
    }

    public JButton getjButtonModificarPlatillo() {
        return jButtonModificarPlatillo;
    }

    public JButton getjButtonEliminarPlatillo() {
        return jButtonEliminarPlatillo;
    }

    public JButton getjButtonBuscarPlatillo() {
        return jButtonBuscarPlatillo;
    }

    public JTable getjtablePlatosEnLaBaseDeDatos() {
        return jtablePlatosEnLaBaseDeDatos;
    }

    public JTextField getTextBuscarPlatillo() {
        return textBuscarPlatillo;
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jtablePlatosEnLaBaseDeDatos = new javax.swing.JTable();
        jButtonModificarPlatillo = new javax.swing.JButton();
        jButtonEliminarPlatillo = new javax.swing.JButton();
        jButtonBuscarPlatillo = new javax.swing.JButton();
        textBuscarPlatillo = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButtonAgregarPlatillos = new javax.swing.JButton();

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(153, 153, 153));
        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jtablePlatosEnLaBaseDeDatos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID_Plato", "Nombre", "Precio", "Descripcion"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(jtablePlatosEnLaBaseDeDatos);
        if (jtablePlatosEnLaBaseDeDatos.getColumnModel().getColumnCount() > 0) {
            jtablePlatosEnLaBaseDeDatos.getColumnModel().getColumn(0).setResizable(false);
            jtablePlatosEnLaBaseDeDatos.getColumnModel().getColumn(1).setResizable(false);
            jtablePlatosEnLaBaseDeDatos.getColumnModel().getColumn(2).setResizable(false);
            jtablePlatosEnLaBaseDeDatos.getColumnModel().getColumn(3).setResizable(false);
        }

        jPanel3.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 820, 320));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 140, 840, 340));

        jButtonModificarPlatillo.setBackground(new java.awt.Color(204, 255, 204));
        jButtonModificarPlatillo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonModificarPlatillo.setText("Modificar");
        jButtonModificarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonModificarPlatilloActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonModificarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 90, -1, 30));

        jButtonEliminarPlatillo.setBackground(new java.awt.Color(255, 102, 102));
        jButtonEliminarPlatillo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonEliminarPlatillo.setText("Eliminar");
        jButtonEliminarPlatillo.setMaximumSize(new java.awt.Dimension(82, 23));
        jButtonEliminarPlatillo.setMinimumSize(new java.awt.Dimension(82, 23));
        jButtonEliminarPlatillo.setPreferredSize(new java.awt.Dimension(82, 23));
        jButtonEliminarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEliminarPlatilloActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonEliminarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 90, -1, 30));

        jButtonBuscarPlatillo.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonBuscarPlatillo.setText("Buscar");
        jButtonBuscarPlatillo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonBuscarPlatilloActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonBuscarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 90, -1, -1));
        jPanel2.add(textBuscarPlatillo, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 90, 150, -1));

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Arial Rounded MT Bold", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Registro de Platos");

        jButtonAgregarPlatillos.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jButtonAgregarPlatillos.setText("AGREGAR PLATILLOS");
        jButtonAgregarPlatillos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAgregarPlatillosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 467, Short.MAX_VALUE)
                .addComponent(jButtonAgregarPlatillos, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(23, 23, 23))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jButtonAgregarPlatillos))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 860, 70));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonModificarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonModificarPlatilloActionPerformed
      int filaSeleccionada = jtablePlatosEnLaBaseDeDatos.getSelectedRow();
    if (filaSeleccionada >= 0) {
        Object idPlatoObj = jtablePlatosEnLaBaseDeDatos.getValueAt(filaSeleccionada, 0);
        if (idPlatoObj != null) {
            int idPlato = (Integer) idPlatoObj; // Asegúrate de que no sea null
            controlador.mostrarFormularioEdicion(idPlato);
        } else {
            JOptionPane.showMessageDialog(this, "El ID del plato es nulo.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Seleccione un platillo para modificar",
            "Advertencia", JOptionPane.WARNING_MESSAGE);
    }
    }//GEN-LAST:event_jButtonModificarPlatilloActionPerformed

    private void jButtonAgregarPlatillosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAgregarPlatillosActionPerformed
        controlador.mostrarFormularioRegistro(null);
    }//GEN-LAST:event_jButtonAgregarPlatillosActionPerformed

    private void jButtonEliminarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEliminarPlatilloActionPerformed
        controlador.eliminarPlatoSeleccionado();
    }//GEN-LAST:event_jButtonEliminarPlatilloActionPerformed

    private void jButtonBuscarPlatilloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonBuscarPlatilloActionPerformed
        controlador.buscarPlatos();
    }//GEN-LAST:event_jButtonBuscarPlatilloActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAgregarPlatillos;
    private javax.swing.JButton jButtonBuscarPlatillo;
    private javax.swing.JButton jButtonEliminarPlatillo;
    private javax.swing.JButton jButtonModificarPlatillo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jtablePlatosEnLaBaseDeDatos;
    private javax.swing.JTextField textBuscarPlatillo;
    // End of variables declaration//GEN-END:variables

}