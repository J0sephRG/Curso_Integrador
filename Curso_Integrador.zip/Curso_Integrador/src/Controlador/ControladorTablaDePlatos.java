package Controlador;

import DAO.PlatoDAO;
import Modelo.Plato;
import Vista.RegistrodePlatillos;
import Vista.TablaDeLosPlatos;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class ControladorTablaDePlatos {
    private final TablaDeLosPlatos vistaTabla;
    private final RegistrodePlatillos vistaRegistro;
    private final PlatoDAO platoDAO;

    public ControladorTablaDePlatos(TablaDeLosPlatos vistaTabla, RegistrodePlatillos vistaRegistro, Connection connection) {
        this.vistaTabla = vistaTabla;
        this.vistaRegistro = vistaRegistro;
        this.platoDAO = new PlatoDAO(connection);
        configurarEventos();
    }

    public void configurarEventos() {
        // Eventos para la vista de tabla
        vistaTabla.getjButtonAgregarPlatillos().addActionListener(e -> mostrarFormularioRegistro(null));
        vistaTabla.getjButtonModificarPlatillo().addActionListener(e -> {
            int filaSeleccionada = vistaTabla.getjtablePlatosEnLaBaseDeDatos().getSelectedRow();
            if (filaSeleccionada >= 0) {
                int idPlato = (Integer) vistaTabla.getjtablePlatosEnLaBaseDeDatos().getValueAt(filaSeleccionada, 0);
                mostrarFormularioEdicion(idPlato);
            } else {
                JOptionPane.showMessageDialog(vistaTabla, "Seleccione un plato para modificar", 
                    "Advertencia", JOptionPane.WARNING_MESSAGE);
            }
        });
        vistaTabla.getjButtonEliminarPlatillo().addActionListener(e -> eliminarPlatoSeleccionado());
        vistaTabla.getjButtonBuscarPlatillo().addActionListener(e -> buscarPlatos());

        // Eventos para la vista de registro
        vistaRegistro.getjButtonGuardarPlatillo().addActionListener(e -> guardarPlato());
        vistaRegistro.getjButtonLimpiarFormulario().addActionListener(e -> vistaRegistro.limpiarFormulario());
        vistaRegistro.getjButtonCancelar().addActionListener(e -> volverATabla());
    }

    public void cargarPlatosEnTabla() {
        try {
            List<Plato> platos = platoDAO.listarPlatos();
            DefaultTableModel modelo = (DefaultTableModel) vistaTabla.getjtablePlatosEnLaBaseDeDatos().getModel();
            modelo.setRowCount(0); // Limpiar tabla

            for (Plato plato : platos) {
                modelo.addRow(new Object[]{
                    plato.getId_plato(),
                    plato.getNombre(),
                    plato.getPrecio(),
                    plato.getDescripcion()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vistaTabla, 
                "Error al cargar platillos: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void eliminarPlatoSeleccionado() {
        int filaSeleccionada = vistaTabla.getjtablePlatosEnLaBaseDeDatos().getSelectedRow();
        if (filaSeleccionada >= 0) {
            int confirmacion = JOptionPane.showConfirmDialog(vistaTabla, 
                "¿Está seguro de eliminar este platillo?", 
                "Confirmar", JOptionPane.YES_NO_OPTION);

            if (confirmacion == JOptionPane.YES_OPTION) {
                int idPlato = (Integer) vistaTabla.getjtablePlatosEnLaBaseDeDatos().getValueAt(filaSeleccionada, 0);

                try {
                    platoDAO.eliminarPlato(idPlato);
                    cargarPlatosEnTabla();
                    JOptionPane.showMessageDialog(vistaTabla, 
                        "Platillo eliminado correctamente", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(vistaTabla, 
                        "Error al eliminar: " + ex.getMessage(), 
                        "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } else {
            JOptionPane.showMessageDialog(vistaTabla, 
                "Seleccione un platillo para eliminar", 
                "Advertencia", JOptionPane.WARNING_MESSAGE);
        }
    }

    public void buscarPlatos() {
        try {
            String criterio = vistaTabla.getTextBuscarPlatillo().getText().trim();
            List<Plato> platos = platoDAO.listarPlatos();

            DefaultTableModel modelo = (DefaultTableModel) vistaTabla.getjtablePlatosEnLaBaseDeDatos().getModel();
            modelo.setRowCount(0);

            platos.stream()
                .filter(p -> p.getNombre().toLowerCase().contains(criterio.toLowerCase()))
                .forEach(p -> modelo.addRow(new Object[]{
                    p.getId_plato(),
                    p.getNombre(),
                    p.getPrecio(),
                    p.getDescripcion()
                }));

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vistaTabla, 
                "Error al buscar: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void mostrarFormularioRegistro(Plato plato) {
        vistaRegistro.setPlato(plato); // Setear el plato en el formulario
        cambiarPanel(vistaRegistro); // Cambiar a la vista de registro
    }

    public void mostrarFormularioEdicion(int idPlato) {
        try {
            Plato plato = platoDAO.obtenerPlato(idPlato);
            mostrarFormularioRegistro(plato); 
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(vistaTabla, 
                "Error al obtener platillo: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void guardarPlato() {
        try {
            Plato plato = vistaRegistro.getPlato(); // Obtener el plato desde el formulario

            if (plato == null) return; // Si el plato es nulo, no hacer nada

            if (validarPlato(plato)) {
                if (plato.getId_plato() == 0) {
                    platoDAO.agregarPlato(plato); // Agregar nuevo plato
                    JOptionPane.showMessageDialog(vistaRegistro, 
                        "Platillo agregado correctamente", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    platoDAO.actualizarPlato(plato); // Actualizar plato existente
                    JOptionPane.showMessageDialog(vistaRegistro, 
                        "Platillo actualizado correctamente", 
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
                }

                vistaRegistro.limpiarFormulario(); // Limpiar el formulario
                volverATabla(); // Volver a la tabla de platos
                cargarPlatosEnTabla(); // Recargar la tabla de platos
            }
        } catch (SQLException | NumberFormatException ex) {
            JOptionPane.showMessageDialog(vistaRegistro, 
                "Error al guardar: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean validarPlato(Plato plato) {
        if (plato.getNombre() == null || plato.getNombre().trim().isEmpty()) {
            JOptionPane.showMessageDialog(vistaRegistro, 
                "El nombre del platillo es requerido", 
                "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (plato.getPrecio() == null || plato.getPrecio().compareTo(BigDecimal.ZERO) <= 0) {
            JOptionPane.showMessageDialog(vistaRegistro, 
                "El precio debe ser mayor que cero", 
                "Validación", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    public void cambiarPanel(javax.swing.JPanel panel) {
        JFrame frame = (JFrame) SwingUtilities.getWindowAncestor(vistaTabla);
        if (frame != null) { // Verificar que el frame no sea null
            frame.setContentPane(panel);
            frame.revalidate();
            frame.repaint();
        } else {
            JOptionPane.showMessageDialog(vistaTabla, "Error: No se pudo encontrar la ventana principal.", 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void volverATabla() {
        cambiarPanel(vistaTabla);
    }
}
