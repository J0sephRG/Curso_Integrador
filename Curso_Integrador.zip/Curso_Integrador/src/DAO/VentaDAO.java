package DAO;

import ConexionSQL.Conexion; // Asegúrate de que esta clase maneje la conexión a SQL Server
import Modelo.Venta;
import java.math.BigDecimal;
import Modelo.DetalleVenta;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;

public class VentaDAO {
    private Connection conn; 

    public VentaDAO(Connection conn) {
        this.conn = conn;
    }

    public int agregarVenta(Venta venta) throws SQLException {
    String query = "INSERT INTO Venta(fecha_venta, id_usuario, metodo_pago, monto_total) VALUES (?, ?, ?, ?)";
    int idGenerado = -1;

    try (PreparedStatement statement = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
        statement.setTimestamp(1, venta.getFecha_venta());
        statement.setObject(2, venta.getId_usuario());
        statement.setString(3, venta.getMetodo_pago());
        statement.setBigDecimal(4, venta.getMonto_total());

        int filasAfectadas = statement.executeUpdate();

        if (filasAfectadas > 0) {
            try (ResultSet rs = statement.getGeneratedKeys()) {
                if (rs.next()) {
                    idGenerado = rs.getInt(1);
                }
            }
        }
    }

    return idGenerado;
}


    public void agregarDetalleVenta(DetalleVenta detalle) throws SQLException {
        String query = "INSERT INTO Detalle_Venta(id_venta, id_producto, cantidad, precio_unitario) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            statement.setInt(1, detalle.getId_venta());
            statement.setInt(2, detalle.getId_producto());
            statement.setInt(3, detalle.getCantidad());
            statement.setBigDecimal(4, detalle.getPrecio_unitario());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public Venta obtenerVenta(int id_venta) throws SQLException {
        String query = "SELECT * FROM Venta WHERE id_venta = ?";
        Venta venta = null;
        try (PreparedStatement statement = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            statement.setInt(1, id_venta);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                venta = new Venta(
                                  rs.getTimestamp("fecha_venta"),
                                  rs.getObject("id_usuario", Integer.class), 
                                  rs.getString("metodo_pago"),
                                  rs.getBigDecimal("monto_total"));
            }
        }
        return venta;
    }

    public List<Venta> listarVentas() throws SQLException {
        List<Venta> ventas = new ArrayList<>();
        String query = "SELECT * FROM Venta";
        try (PreparedStatement statement = conn.prepareStatement(query); // Cambiado 'connection' a 'conn'
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                ventas.add(new Venta( 
                                     rs.getTimestamp("fecha_venta"),
                                     rs.getObject("id_usuario", Integer.class), 
                                     rs.getString("metodo_pago"),
                                     rs.getBigDecimal("monto_total")));
            }
        }
        return ventas;
    }

    public void actualizarVenta(Venta venta) throws SQLException {
        String query = "UPDATE Venta SET fecha_venta = ?, id_usuario = ?, metodo_pago = ?, monto_total = ? WHERE id_venta = ?";
        try (PreparedStatement statement = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            statement.setTimestamp(1, venta.getFecha_venta());
            statement.setObject(2, venta.getId_usuario());
            statement.setString(3, venta.getMetodo_pago());
            statement.setBigDecimal(4, venta.getMonto_total());
            statement.setInt(5, venta.getId_venta());
            statement.executeUpdate();
        }
    }

    public void eliminarVenta(int id_venta) throws SQLException {
        String query = "DELETE FROM Venta WHERE id_venta = ?";
        try (PreparedStatement statement = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            statement.setInt(1, id_venta);
            statement.executeUpdate();
        }
    }

    /** Obtiene ventas realizadas por un usuario específico */
    public List<Venta> listarVentasPorUsuario(int idUsuario) throws SQLException {
        String query = "SELECT * FROM Venta WHERE id_usuario = ?";
        List<Venta> ventas = new ArrayList<>();
        try (PreparedStatement stmt = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            stmt.setInt(1, idUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    ventas.add(new Venta(
                        
                        rs.getTimestamp("fecha_venta"),
                        rs.getObject("id_usuario", Integer.class),
                        rs.getString("metodo_pago"),
                        rs.getBigDecimal("monto_total")
                    ));
                }
            }
        }
        return ventas;
    }

    /** Suma total vendida en un rango de fechas */
    public BigDecimal totalVentasPorFecha(Timestamp fechaInicio, Timestamp fechaFin) throws SQLException {
        String query = "SELECT SUM(monto_total) AS total FROM Venta WHERE fecha_venta BETWEEN ? AND ?";
        try (PreparedStatement stmt = conn.prepareStatement(query)) { // Cambiado 'connection' a 'conn'
            stmt.setTimestamp(1, fechaInicio);
            stmt.setTimestamp(2, fechaFin);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("total");
                }
            }
        }
        return BigDecimal.ZERO;
    }
}
