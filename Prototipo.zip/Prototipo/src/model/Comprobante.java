/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class Comprobante {
    private String tipoPago;
    private String tipoComprobante;
    private double total;
    private double igv;
    private double montoPago;
    private double montoCobrar;
    private double vuelto;
    private double descuento;

    // Constructor
    public Comprobante(String tipoPago, String tipoComprobante, double total, double igv,
                       double montoPago, double montoCobrar, double vuelto, double descuento) {
        this.tipoPago = tipoPago;
        this.tipoComprobante = tipoComprobante;
        this.total = total;
        this.igv = igv;
        this.montoPago = montoPago;
        this.montoCobrar = montoCobrar;
        this.vuelto = vuelto;
        this.descuento = descuento;
    }

    // Métodos Getters y Setters
    // (Agrega los métodos según lo que necesites)

    public String getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(String tipoPago) {
        this.tipoPago = tipoPago;
    }

    public String getTipoComprobante() {
        return tipoComprobante;
    }

    public void setTipoComprobante(String tipoComprobante) {
        this.tipoComprobante = tipoComprobante;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getIgv() {
        return igv;
    }

    public void setIgv(double igv) {
        this.igv = igv;
    }

    public double getMontoPago() {
        return montoPago;
    }

    public void setMontoPago(double montoPago) {
        this.montoPago = montoPago;
    }

    public double getMontoCobrar() {
        return montoCobrar;
    }

    public void setMontoCobrar(double montoCobrar) {
        this.montoCobrar = montoCobrar;
    }

    public double getVuelto() {
        return vuelto;
    }

    public void setVuelto(double vuelto) {
        this.vuelto = vuelto;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
}
