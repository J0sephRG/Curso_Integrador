package DAO;

import Conexion.DatabaseConnection;
import model.MovimientoInventario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MovimientoInventarioDAO {
    private Connection connection;

    public MovimientoInventarioDAO(Connection connection) throws SQLException {
         this.connection = DatabaseConnection.getConnection(); // Obtener la conexión de la base de datos
    }

    public void agregarMovimiento(MovimientoInventario movimiento) throws SQLException {
        String query = "INSERT INTO Movimiento_Inventario(id_producto, fecha_movimiento, tipo_movimiento, cantidad) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, movimiento.getId_producto());
            statement.setTimestamp(2, movimiento.getFecha_movimiento());
            statement.setString(3, movimiento.getTipo_movimiento());
            statement.setInt(4, movimiento.getCantidad());
            statement.executeUpdate();
        }
    }

    public MovimientoInventario obtenerMovimiento(int id_movimiento) throws SQLException {
        String query = "SELECT * FROM Movimiento_Inventario WHERE id_movimiento = ?";
        MovimientoInventario movimiento = null;
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_movimiento);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                movimiento = new MovimientoInventario(rs.getInt("id_movimiento"), rs.getInt("id_producto"),
                                                      rs.getTimestamp("fecha_movimiento"), rs.getString("tipo_movimiento"),
                                                      rs.getInt("cantidad"));
            }
        }
        return movimiento;
    }

    public List<MovimientoInventario> listarMovimientos() throws SQLException {
        List<MovimientoInventario> movimientos = new ArrayList<>();
        String query = "SELECT * FROM Movimiento_Inventario";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                movimientos.add(new MovimientoInventario(rs.getInt("id_movimiento"), rs.getInt("id_producto"),
                                                         rs.getTimestamp("fecha_movimiento"), rs.getString("tipo_movimiento"),
                                                         rs.getInt("cantidad")));
            }
        }
        return movimientos;
    }

    public void actualizarMovimiento(MovimientoInventario movimiento) throws SQLException {
        String query = "UPDATE Movimiento_Inventario SET id_producto = ?, fecha_movimiento = ?, tipo_movimiento = ?, cantidad = ? WHERE id_movimiento = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, movimiento.getId_producto());
            statement.setTimestamp(2, movimiento.getFecha_movimiento());
            statement.setString(3, movimiento.getTipo_movimiento());
            statement.setInt(4, movimiento.getCantidad());
            statement.setInt(5, movimiento.getId_movimiento());
            statement.executeUpdate();
        }
    }

    public void eliminarMovimiento(int id_movimiento) throws SQLException {
        String query = "DELETE FROM Movimiento_Inventario WHERE id_movimiento = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_movimiento);
            statement.executeUpdate();
        }
    }
}
