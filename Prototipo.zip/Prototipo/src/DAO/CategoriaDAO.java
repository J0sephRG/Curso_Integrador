package DAO;

import model.Categoria;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {
    private Connection connection;

    public CategoriaDAO(Connection connection) {
        this.connection = connection;
    }

    public void agregarCategoria(Categoria categoria) throws SQLException {
        String query = "INSERT INTO Categoria(nombre_categoria, descripcion) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, categoria.getNombre_categoria());
            statement.setString(2, categoria.getDescripcion());
            statement.executeUpdate();
        }
    }

    public Categoria obtenerCategoria(int id_categoria) throws SQLException {
        String query = "SELECT * FROM Categoria WHERE id_categoria = ?";
        Categoria categoria = null;
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_categoria);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                categoria = new Categoria(rs.getInt("id_categoria"), rs.getString("nombre_categoria"),
                                          rs.getString("descripcion"));
            }
        }
        return categoria;
    }

    public List<Categoria> listarCategorias() throws SQLException {
        List<Categoria> categorias = new ArrayList<>();
        String query = "SELECT * FROM Categoria";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                categorias.add(new Categoria(rs.getInt("id_categoria"), rs.getString("nombre_categoria"),
                                             rs.getString("descripcion")));
            }
        }
        return categorias;
    }

    public void actualizarCategoria(Categoria categoria) throws SQLException {
        String query = "UPDATE Categoria SET nombre_categoria = ?, descripcion = ? WHERE id_categoria = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, categoria.getNombre_categoria());
            statement.setString(2, categoria.getDescripcion());
            statement.setInt(3, categoria.getId_categoria());
            statement.executeUpdate();
        }
    }

    public void eliminarCategoria(int id_categoria) throws SQLException {
        String query = "DELETE FROM Categoria WHERE id_categoria = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_categoria);
            statement.executeUpdate();
        }
    }
}
