package DAO;

import model.Producto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAO {
    private Connection connection;

    public ProductoDAO(Connection connection) {
        this.connection = connection;
    }

    public void agregarProducto(Producto producto) throws SQLException {
        String query = "INSERT INTO Producto(nombre, stock_actual, stock_minimo, precio_unitario, unidad_medida, id_categoria, descripcion) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, producto.getNombre());
            statement.setInt(2, producto.getStock_actual());
            statement.setInt(3, producto.getStock_minimo());
            statement.setBigDecimal(4, producto.getPrecio_unitario());
            statement.setString(5, producto.getUnidad_medida());
            statement.setObject(6, producto.getId_categoria());
            statement.setString(7, producto.getDescripcion());
            statement.executeUpdate();
        }
    }

    public Producto obtenerProducto(int id_producto) throws SQLException {
        String query = "SELECT * FROM Producto WHERE id_producto = ?";
        Producto producto = null;
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_producto);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                producto = new Producto(rs.getInt("id_producto"), rs.getString("nombre"),
                                        rs.getInt("stock_actual"), rs.getInt("stock_minimo"),
                                        rs.getBigDecimal("precio_unitario"), rs.getString("unidad_medida"),
                                        rs.getObject("id_categoria", Integer.class), rs.getString("descripcion"));
            }
        }
        return producto;
    }

    public List<Producto> listarProductos() throws SQLException {
        List<Producto> productos = new ArrayList<>();
        String query = "SELECT * FROM Producto";
        try (PreparedStatement statement = connection.prepareStatement(query);
             ResultSet rs = statement.executeQuery()) {
            while (rs.next()) {
                productos.add(new Producto(rs.getInt("id_producto"), rs.getString("nombre"),
                                           rs.getInt("stock_actual"), rs.getInt("stock_minimo"),
                                           rs.getBigDecimal("precio_unitario"), rs.getString("unidad_medida"),
                                           rs.getObject("id_categoria", Integer.class), rs.getString("descripcion")));
            }
        }
        return productos;
    }

    public void actualizarProducto(Producto producto) throws SQLException {
        String query = "UPDATE Producto SET nombre = ?, stock_actual = ?, stock_minimo = ?, precio_unitario = ?, unidad_medida = ?, id_categoria = ?, descripcion = ? WHERE id_producto = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, producto.getNombre());
            statement.setInt(2, producto.getStock_actual());
            statement.setInt(3, producto.getStock_minimo());
            statement.setBigDecimal(4, producto.getPrecio_unitario());
            statement.setString(5, producto.getUnidad_medida());
            statement.setObject(6, producto.getId_categoria());
            statement.setString(7, producto.getDescripcion());
            statement.setInt(8, producto.getId_producto());
            statement.executeUpdate();
        }
    }

    public void eliminarProducto(int id_producto) throws SQLException {
        String query = "DELETE FROM Producto WHERE id_producto = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id_producto);
            statement.executeUpdate();
        }
    }
}

