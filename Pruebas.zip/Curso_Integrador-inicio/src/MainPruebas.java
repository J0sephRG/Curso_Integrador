
import Controlador.ControladorPedidos;
import Vista.TablaDePEDIDOS;
import Vista.TablaDePEDIDOSDElivery;



public class MainPruebas {
    public static void main(String[] args) {
        // Crear el controlador en modo prueba (sin conexión a BD)
        ControladorPedidos controlador = new ControladorPedidos(true);
        
        // Mostrar las ventanas de la GUI
        javax.swing.SwingUtilities.invokeLater(() -> {
            new TablaDePEDIDOSDElivery(controlador).setVisible(true);
            new TablaDePEDIDOS(controlador).setVisible(false);
        });
    }
}
