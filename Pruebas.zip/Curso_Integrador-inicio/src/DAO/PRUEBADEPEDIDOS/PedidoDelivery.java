
package DAO.PRUEBADEPEDIDOS;


import Interface.Pedido;
import java.sql.Timestamp;

public class PedidoDelivery implements Pedido {
    private int id;
    private int idCliente;
    private String direccionEntrega;
    private String estado;
    private Timestamp fechaPedido;

    public PedidoDelivery(int id, int idCliente, String direccionEntrega, 
                         String estado, Timestamp fechaPedido) {
        this.id = id;
        this.idCliente = idCliente;
        this.direccionEntrega = direccionEntrega;
        this.estado = estado;
        this.fechaPedido = fechaPedido;
    }

    @Override public int getId() { return id; }
    @Override public void setId(int id) { this.id = id; }
    @Override public int getIdCliente() { return idCliente; }
    @Override public void setIdCliente(int idCliente) { this.idCliente = idCliente; }
    @Override public String getEstado() { return estado; }
    @Override public void setEstado(String estado) { this.estado = estado; }
    @Override public Timestamp getFechaPedido() { return fechaPedido; }
    @Override public void setFechaPedido(Timestamp fechaPedido) { this.fechaPedido = fechaPedido; }
    @Override public String getDireccionEntrega() { return direccionEntrega; }
    
    @Override
    public double calcularTotal() {
        return 10.0; // Valor simplificado para pruebas
    }

    @Override
    public String getTipoPedido() {
        return "DELIVERY";
    }
}
