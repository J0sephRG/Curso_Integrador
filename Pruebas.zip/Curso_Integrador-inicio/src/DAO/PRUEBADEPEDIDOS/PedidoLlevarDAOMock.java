package DAO.PRUEBADEPEDIDOS;

import DAO.PRUEVAINTERFACE.PedidoDAO;
import Interface.Pedido;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class PedidoLlevarDAOMock implements PedidoDAO {
    private final List<Pedido> pedidos = new ArrayList<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);

    @Override
    public void insertar(Pedido pedido) {
        PedidoLlevar pl = (PedidoLlevar) pedido;
        pl.setId(idGenerator.getAndIncrement());
        pedidos.add(pl);
    }

    @Override
    public List<Pedido> listarTodos() {
        return new ArrayList<>(pedidos);
    }

    @Override
    public void actualizar(Pedido pedido) {
        PedidoLlevar nuevo = (PedidoLlevar) pedido;
        for (int i = 0; i < pedidos.size(); i++) {
            Pedido existente = pedidos.get(i);
            if (existente.getId() == nuevo.getId()) {
                pedidos.set(i, nuevo);
                break;
            }
        }
    }

    @Override
    public void eliminar(int id) {
        pedidos.removeIf(p -> p.getId() == id);
    }

    @Override
    public Pedido buscarPorId(int id) {
        return pedidos.stream()
                     .filter(p -> p.getId() == id)
                     .findFirst()
                     .orElse(null);
    }
}
