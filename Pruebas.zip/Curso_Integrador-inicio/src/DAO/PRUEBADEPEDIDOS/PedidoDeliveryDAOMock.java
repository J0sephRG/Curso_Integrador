package DAO.PRUEBADEPEDIDOS;
import DAO.PRUEVAINTERFACE.PedidoDAO;
import Interface.Pedido;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class PedidoDeliveryDAOMock implements PedidoDAO {
    private final List<Pedido> pedidos = new ArrayList<>();
    private final AtomicInteger idGenerator = new AtomicInteger(1);

    @Override
    public void insertar(Pedido pedido) {
        PedidoDelivery pd = (PedidoDelivery) pedido;
        pd.setId(idGenerator.getAndIncrement());
        pedidos.add(pd);
    }

    @Override
    public List<Pedido> listarTodos() {
        return new ArrayList<>(pedidos);
    }

    @Override
    public void actualizar(Pedido pedido) {
        PedidoDelivery nuevo = (PedidoDelivery) pedido;
        for (int i = 0; i < pedidos.size(); i++) {
            Pedido existente = pedidos.get(i);
            if (existente.getId() == nuevo.getId()) {
                pedidos.set(i, nuevo);
                break;
            }
        }
    }

    @Override
    public void eliminar(int id) {
        pedidos.removeIf(p -> p.getId() == id);
    }

    @Override
    public Pedido buscarPorId(int id) {
        return pedidos.stream()
                     .filter(p -> p.getId() == id)
                     .findFirst()
                     .orElse(null);
    }
}
