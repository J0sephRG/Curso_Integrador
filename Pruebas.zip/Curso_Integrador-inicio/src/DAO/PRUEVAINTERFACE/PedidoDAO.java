/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO.PRUEVAINTERFACE;

import Interface.Pedido;
import java.util.List;

public interface PedidoDAO {
    void insertar(Pedido pedido);
    void actualizar(Pedido pedido);
    void eliminar(int id);
    Pedido buscarPorId(int id);
    List<Pedido> listarTodos();
}
